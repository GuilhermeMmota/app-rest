var config = {
  apiKey: "AIzaSyBM9h803KM7AhtxFv5jlscEHjPp-POjWwM",
  authDomain: "bike-8bbe8.firebaseapp.com",
  databaseURL: "https://bike-8bbe8.firebaseio.com",
  projectId: "bike-8bbe8",
  storageBucket: "bike-8bbe8.appspot.com",
  messagingSenderId: "420328899231"
};
firebase.initializeApp(config);
